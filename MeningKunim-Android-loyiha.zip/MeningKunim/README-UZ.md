# Mening Kunim — Android APK loyihasi

Bu loyiha siz yuborgan HTML/CSS/JavaScript ilovasini Android WebView ichida ishga tushiradi.

## Loyiha tarkibi
- `app/src/main/assets/htmlapp/index.html` — ilova interfeysi
- `style.css` — dizayn
- `script.js` — vazifalar, dars jadvali, musiqa, tanga va avatar do‘koni
- `MainActivity.kt` — Android WebView qobig‘i
- `.github/workflows/build-apk.yml` — GitHub Actions orqali APK yig‘ish

## APK olish (planshetdan ham mumkin)
1. GitHub hisobingizga kiring va yangi repository yarating, masalan `MeningKunim`.
2. Ushbu ZIP ichidagi **fayllarni** repository rootiga yuklang (papkani ichma-ich qilib yubormang).
3. `app/src/main/assets/htmlapp/` ichidagi fayllar joyida ekanini tekshiring.
4. GitHub’da **Actions** bo‘limini oching.
5. `Build Mening Kunim APK` workflow’ini tanlang va **Run workflow** bosing.
6. Ish tugagach, workflow run sahifasidagi **Artifacts** qismidan `Mening-Kunim-debug-apk` faylini yuklab oling.
7. ZIP artifactni ochib, `app-debug.apk` faylini Samsung planshetingizga o‘rnating. Android xavfsizlik oynasi chiqsa, faqat o‘zingiz boshlagan yuklab olish uchun brauzer/fayl menejeriga ruxsat bering.

## Muhim
- Bu debug APK; o‘zingiz sinash uchun.
- Bu muhitda Android SDK bilan APK’ni to‘g‘ridan-to‘g‘ri yig‘ish bajarilmadi. APK’ni GitHub Actions yig‘adi.
- Ilova ma’lumotlari qurilma ichida saqlanadi. Ilovani o‘chirib tashlashda ma’lumotlar ham yo‘qolishi mumkin.
